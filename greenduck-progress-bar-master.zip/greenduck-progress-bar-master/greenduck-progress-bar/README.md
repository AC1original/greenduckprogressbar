# greenduck-progress-bar
IntelliJ Idea plugin for greenduck progress bar
    
------------------------[CREDITS]------------------------------------
    
> Green Duck (Owner)

    [Discord Server] https://discord.gg/QgqZk7ftmA
    [YouTube] https://www.youtube.com/@GreenDuckStudio
    [TikTok] https://www.tiktok.com/@greenduckstudio

> AC_1 (Developer) 

    [Discord Username] ac1original